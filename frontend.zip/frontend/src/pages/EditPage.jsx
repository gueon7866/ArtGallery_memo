[Immersive content redacted for brevity.]
